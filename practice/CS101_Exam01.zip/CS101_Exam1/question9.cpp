#include <stdio.h>

int main(void) {
	// Declare variable for input value
	// TODO

	// Read input value
	// TODO

	// Check value against conditions and print
	// appropriate output
	// TODO

	return 0;
}
