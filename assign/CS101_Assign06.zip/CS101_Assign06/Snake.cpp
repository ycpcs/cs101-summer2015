#include <stdlib.h>
#include <time.h>
#include "Console.h"

// Default frames per second.
#define FPS 10

// TODO: define other struct types, e.g., struct Point, struct Snake

struct Scene {
	// TODO: add fields
};

// TODO: define functions to operate on your struct types

void scene_init(struct Scene *s);
void scene_render(const struct Scene *s);
int scene_update(struct Scene *s);
void scene_delay(struct Scene *s);

int main(void) {
	// Important: do NOT modify the main function
	struct Scene scene;

	scene_init(&scene);

	int keep_going = 1;
	while (keep_going == 1) {
		scene_render(&scene);
		cons_update();
		scene_delay(&scene);
		keep_going = scene_update(&scene);
	}

	return 0;
}

void scene_init(struct Scene *s) {
	srand(time(0));

	// TODO: add your code
}

void scene_render(const struct Scene *s) {
	// TODO: add your code
}

int scene_update(struct Scene *s) {
	// This function should return 0 if the player presses 'q',
	// 1 otherwise.

	int key = cons_get_keypress();

	// TODO: add your code

	return 1;
}

void scene_delay(struct Scene *s) {
	// This function determines how many milliseconds the game is
	// paused between each frame of animation.
	// You can modify this if you want to vary the game speed.
	cons_sleep_ms(1000/FPS);
}
