#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Console.h" // terminal graphics functions

// Dimensions of game board
#define HEIGHT 20
#define WIDTH 60

// Function prototypes
void load_board(int board[HEIGHT][WIDTH], const char *filename);
void init_random_board(int board[HEIGHT][WIDTH]);
void print_board(int board[HEIGHT][WIDTH]);
int get_cell(int board[HEIGHT][WIDTH], int row, int col);
int count_neighbors(int board[HEIGHT][WIDTH], int row, int col);
void compute_next_gen(int board[HEIGHT][WIDTH]);

int main(void)
{
	// This is the game board
	int board[HEIGHT][WIDTH];

	int choice;
	do {
		printf("(0) Load from file, or (1) initialize random board? ");
		scanf("%i", &choice);
	} while (choice < 0 || choice > 1);

	if (choice == 0) {
		char fname[1024];
		printf("Name of file to load: ");
		scanf("%s", fname);
		load_board(board, fname);
	} else {
		srand(time(0));
		init_random_board(board);
	}

	int num_gens;
	printf("How many generations? ");
	scanf("%i", &num_gens);

	// TODO: print initial game state, run simulation, print final state, etc.

	return 0;
}

// Load game board from file
void load_board(int board[HEIGHT][WIDTH], const char *filename)
{
	FILE *in = fopen(filename, "r");
	if (!in) {
		printf("Error opening %s\n", filename);
		exit(1);
	}
	for (int i = 0; i < HEIGHT; i++) {
		for (int j = 0; j < WIDTH; j++) {
			fscanf(in, "%i", &board[i][j]);
		}
	}
	fclose(in);
}

// TODO: implement functions
