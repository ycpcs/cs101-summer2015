#include <stdio.h>

int main(void) {
	int val = 20;
	if (val > 20) {
		printf("A\n");
	}
	if (val < 20) {
		printf("B\n");
	}

	return 0;
}
